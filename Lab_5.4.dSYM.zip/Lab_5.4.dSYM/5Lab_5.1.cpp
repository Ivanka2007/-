#include <iostream>
#include <cmath>

using namespace std;

double f(const double a, const double b, const double c);

int main()
{
    double a, b;
    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    double c = (f(t, s, 2) + f(1, s + t, t - s)) / (1 + pow(f, 2)(1, pow(1t + s, 2)));

    cout << "c = " << c << endl;

    return 0; 
}

double f(const double a, const double b, const double c) {
    return (a + b + c) / (pow(sin, 2)ab + pow(c, 2));
}